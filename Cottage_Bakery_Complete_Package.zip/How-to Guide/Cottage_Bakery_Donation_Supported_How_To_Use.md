# How to Use Your Donation-Supported Bakery Spreadsheet

## Free products. Optional donations. Clear records.

This workbook is designed for a bakery or bake stand where **all products are free and donations are completely voluntary**. It helps you answer four practical questions:

- How much support did we receive?
- How much money did we spend?
- How many products did we give away?
- How much money is available to keep the bakery running?

**A giveaway and a donation are separate activities.** Someone can take a product without donating, and someone can donate without taking a product. Neither situation creates a customer balance or an amount owed.

This guide applies to:

- **Editable workbook:** `Cottage_Bakery_DONATION_SUPPORTED.xlsx`
- **Protected workbook:** `Cottage_Bakery_DONATION_SUPPORTED_LOCKED.xlsx`
- **Sheet-protection password:** `premium`

> **The most important rule:** Record donations in **Donations**, products given away in **Free Product Log**, and actual payments in **Expense Log**. Recipe values and budgets help you plan; they are not additional cash expenses.

## 1. Open the workbook and prepare your working copy

1. Open the donation-supported workbook in Microsoft Excel.
2. Save a working copy using your bakery's name, such as `Community_Bakery_Records.xlsx`.
3. Use the **protected version** for everyday entry if you want to reduce accidental changes to formulas.
4. Start in **Instructions + Setup**.

### What you can edit

- **Yellow cells:** Enter your information here.
- **Calculated and reference cells:** Leave these unchanged. In the protected edition, formula cells are locked.
- **Dropdowns:** Choose an existing product, recipe, ingredient, donor, event, category, or payment method where a list is provided.
- **Entry check / Costing check columns:** Read these messages; do not type over them.

If you need to remove sheet protection, use **Review → Unprotect Sheet** and enter `premium`. Only do this for intentional structural changes, and protect the sheet again afterward.

### What is already in the file

The Donations, Free Product Log, Expense Log, Donors, and Bake Stand Events entry areas start blank. Old example sales, customer debts, and pending orders were not converted into donations.

Some ingredient values, recipes, products, overhead budgets, and startup plans remain as **labelled examples**. Replace or clear these planning inputs before relying on them. A nonzero budget on the Dashboard does **not** mean that money has actually been spent.

You can start tracking donations and expenses before completing every recipe. Free-product quantities can also be tracked while costs are unfinished, as long as valid Product IDs and giveaway quantities are entered.

## 2. Complete Instructions + Setup

Enter your information in the yellow cells in column B.

| Cell | Setting | How to use it |
|---|---|---|
| B6 | Bakery name | Enter the name you want displayed on the Dashboard. |
| B7 | Currency label | Use one currency throughout the workbook. Changing this label does not convert existing amounts. |
| B8 | Reporting period start | Enter the first date you want included in period totals. |
| B9 | Reporting period end | Enter the last date you want included. The end date is inclusive. |
| B10 | Opening funds | Enter bakery funds available **before the first transaction recorded in this workbook**. |
| B11 | Net donation goal for this period | Enter an optional support target after processing fees. Leave at 0 if you do not want a goal. |
| B12 | Labor planning value / hour | Use 0 for unpaid labor in a cash-oriented estimate, or enter a value to understand labor resources. This does not record wages paid. |
| B13 | Calculator packaging value / unit | Default packaging value for the three scratch Recipe Calculators. Recipe Library packaging is entered separately for each recipe. |
| B14 | Planning waste allowance | Enter a percentage, such as **5%**, not the whole number 5. It applies to ingredient and packaging values. |
| B15 | Planned monthly working hours | Used for the overhead-per-hour planning estimate. |
| B16 | Planned monthly giveaway units | Used for the overhead-per-giveaway planning estimate. |
| B17 | Monthly ingredient / packaging budget | Optional variable-cost budget, separate from actual paid expenses. |

### Opening funds: avoid counting the same money twice

If you already have 50 in the bakery fund when you begin using the workbook, enter **50 in B10**. Do not also enter that same 50 as a new donation.

Opening funds are not reset each month when you keep using the same workbook. Change the reporting dates instead; earlier transactions remain part of the cumulative funds calculation.

### Your donation goal is not a product price

A goal such as 200 means “we hope to receive 200 of net support during this reporting period.” It does not mean visitors must donate, and it does not change the required payment for any product from 0.

The reporting dates are entered manually. Update them when you want a different day, month, quarter, or other period.

## 3. Define what you give away in Product List

Before recording giveaways, enter or review your products in **Product List**.

For each product, complete the yellow input fields:

- **Product ID:** A unique, stable code.
- **Product name:** The name of the item.
- **Giveaway unit:** What one entry unit means, such as one loaf or one box.
- **Recipe ID:** The recipe used to calculate its resource value.
- **Recipe units / giveaway:** How many recipe portions are included in one giveaway unit.
- **Notes:** Optional information.

The supplied examples use these definitions:

| Product ID | Product | One giveaway unit | Recipe units / giveaway |
|---|---|---|---:|
| BRD-001 | Sourdough Loaf | 1 loaf | 1 |
| CK-002 | Chocolate Chip Cookies dozen | 1 dozen-cookie box | 12 |
| PAS-003 | Cinnamon Roll 6-pack | 1 six-roll pack | 6 |

**Example:** If you hand out two dozen-cookie boxes, enter **2 units**, not 24. If you want to count individual cookies, create a separate product whose giveaway unit is “1 cookie.”

The **Required payment** column remains **0**. The resource value is an estimate of what it takes to provide the item, not a charge to the recipient.

Keep Product IDs stable once they have been used. If you change an item from a single cookie to a twelve-cookie box, create a new Product ID rather than changing the meaning of old giveaway records.

## 4. Record voluntary support in Donations

Use this tab for **money actually received**, not promised donations or the estimated value of donated supplies.

Each row can represent an individual gift or a clearly identified cash-jar total for a day or event.

### Fields you enter

| Field | Required? | What to enter |
|---|---|---|
| Date received | Yes | The date the money was received. |
| Donor ID | No | Select an ID already created in Donors. Leave blank for an anonymous gift. |
| Event ID | No | Select an existing event if you want the gift included in that event's totals. |
| Method | Yes | Cash, Card, Bank transfer, Mobile wallet, Check, or Other. |
| Gross gift | Yes | The full gift amount before processing fees; it must be positive. |
| Processing fee | No | The actual fee deducted from this gift. Blank means no fee. |
| Payment reference | No | A bank, payment-provider, or internal reference. |
| Notes / intended use | No | Details such as “Saturday cash jar” or the donor's stated intention. |

The workbook fills in **Entry ID**, **Donor / Anonymous**, **Net received**, and **Entry check**.

**Net received = Gross gift − Processing fee**

For example, a gift of 40 with a processing fee of 2 contributes **38** to available funds. Do not also record that same 2 fee in Expense Log.

### Anonymous cash-jar donations

At the end of a bake stand:

1. Count the new donations collected in the jar.
2. Enter the received date.
3. Leave Donor ID blank; the workbook displays **Anonymous**.
4. Select the Event ID if you are using events.
5. Choose **Cash** and enter the jar total as Gross gift.
6. Add a note identifying the day or event.

Record either the jar total or its individual gifts—not both. Do not include money that was already in the jar and already recorded.

### No donation was received

Do **not** create a donation row with an amount of 0. Simply record any products given away in Free Product Log. A giveaway does not require a donation entry.

### Check your entry

A completed valid donation row should show **OK** in Entry check. An invalid donation row is excluded from cash totals until corrected. In particular, a processing fee cannot be greater than the gift.

The intended-use note is descriptive only. It does not automatically restrict, allocate, or reserve funds for a particular purpose.

## 5. Record giveaways in Free Product Log

Use a separate row for each product and date or event you want to track. You can combine several giveaways of the same product on the same day into one quantity if that suits your records.

Enter:

1. **Date given**.
2. **Event ID**, if applicable.
3. **Product ID** from Product List.
4. **Units given**, using the product's giveaway-unit definition.
5. Optional **Notes**.

The workbook supplies the product name, giveaway unit, required payment of 0, and any available resource-cost estimate.

You do not need the recipient's name. You do not need to match this row to a donation. Enter a positive whole number of giveaway units; unused rows should remain empty.

### Entry check and Costing check mean different things

- **Entry check:** Is the giveaway record valid—for example, a valid date, recognized Product ID, and positive whole quantity?
- **Costing check:** Is a usable recipe-based resource value available?

A valid giveaway with a missing recipe cost can still count toward giveaway quantities. Its estimated resource value stays blank, and the costing warning tells you to finish the product or recipe setup.

**Total giveaway units are not necessarily individual baked pieces.** Six loaves plus two dozen-cookie boxes count as eight giveaway units, using those product definitions. These quantities also do not measure unique people served.

## 6. Record actual payments in Expense Log

Use Expense Log whenever bakery money is actually paid out.

Required fields are:

- **Date paid**
- **Category**
- **Description**
- **Amount paid**—a positive amount
- **Method**

Optional fields are Supplier / payee, Event ID, Startup Item ID, Receipt / reference, and Notes.

Available categories include Ingredients, Packaging, Rent, Utilities, Insurance, Licenses, Transport, Equipment, Marketing, Cleaning, Software, Donation refund, Bank fees, and Other. Use **Other** with a clear description when an expense does not fit a listed category—for example, paid labor.

### Record each payment once

Examples of cash expenses include a bag of flour, packaging, a utility bill, or equipment purchased for the bakery. Record the actual amount paid, including any tax included in that payment.

Do **not** enter any of the following as additional cash expenses:

- Recipe resource values calculated elsewhere in the workbook.
- Monthly overhead budgets that have not been paid.
- Unpaid volunteer labor.
- Donated supplies for which no bakery money was paid.
- Processing fees already deducted in Donations.

Buying flour is one cash payment. Using that flour in several recipes is not several more cash payments.

### Event and startup links

Select an **Event ID** if the payment belongs in that event's cash summary.

Select a **Startup Item ID** if the payment should also appear as paid against a startup plan. This is a link to the same payment—not a second expense.

A donation refund can be recorded as a positive payment in the Donation refund category. It reduces available cash, but it does not automatically revise the donor's original gift totals. Keep a clear note and any supporting records.

## 7. Worked example: one bake-stand day

The following is a teaching example, not data already entered in your transaction logs.

Assume:

- Opening funds are **50**.
- Your reporting dates include the example day.
- No other transactions have been recorded.
- You give away six loaves and two dozen-cookie boxes.
- The cash jar receives 25.
- Another supporter gives 40 by card, with a fee of 2.
- You pay 8 for ingredients and 12 for equipment.

### A. Optional event setup

In Bake Stand Events, create an Event ID such as **EVT-001**, enter the event date, and name it “Community Bake Stand.” Use this ID in the relevant logs if you want an event summary.

### B. Donations

| Donation | Method | Gross gift | Fee | Net received |
|---|---|---:|---:|---:|
| Anonymous cash jar | Cash | 25 | 0 | 25 |
| Card gift | Card | 40 | 2 | 38 |
| **Total** | | **65** | **2** | **63** |

The card gift can also be anonymous, or you can create a donor record first.

### C. Free Product Log

| Product ID | Giveaway unit | Units given | Required payment |
|---|---|---:|---:|
| BRD-001 | 1 loaf | 6 | 0 |
| CK-002 | 1 dozen-cookie box | 2 | 0 |
| **Total giveaway units** | | **8** | **0** |

You are recording what was given away—not what each donor “bought.”

### D. Expense Log

| Category | Description | Amount paid |
|---|---|---:|
| Ingredients | Ingredient purchase | 8 |
| Equipment | Equipment purchase | 12 |
| **Total** | | **20** |

Complete each expense's date and payment method. Add a Startup Item ID to the equipment payment only if it belongs to a matching startup plan.

### E. Expected Dashboard results

- Gross gifts: **65**
- Processing fees: **2**
- Net donations: **63**
- Actual cash expenses: **20**
- Cash surplus: **63 − 20 = 43**
- Funds available: **50 + 63 − 20 = 93**
- Free giveaway units: **8**

If the optional net donation goal is 200, the goal is **31.5% funded**, with **137 still needed**. Opening funds do not count as new donations toward that period's goal.

The recipe values and planning budgets are not subtracted again. Missing recipe costs may leave giveaway resource values incomplete, but they do not change the cash arithmetic above.

## 8. Read the Dashboard correctly

### Cash and community figures

| Metric | Meaning |
|---|---|
| Net donations (period) | Valid donations received within the reporting dates, after their processing fees. |
| Gross gifts (period) | Those gifts before fees. Do not add this to Net donations; they describe the same gifts. |
| Donation processing fees | Fees already deducted when Net donations was calculated. Do not subtract them again. |
| Actual cash expenses (period) | Valid payments recorded in Expense Log within the reporting dates. |
| Cash surplus / (shortfall) | Period net donations minus period cash expenses. This is a cash-flow measure, not accounting profit. |
| Free giveaway units (period) | Valid quantities in Free Product Log during the reporting period. |
| Funds available at report end | Opening funds plus all valid net donations through that date, minus all valid paid expenses through that date. |
| Net donations / actual expenses | How much recorded expense is covered by net donations. It is blank when no expenses are recorded. |
| Goal funded / Goal still needed | Progress against your optional period net-donation target. |

**Funds available includes earlier transactions**, not only those after the reporting start date. The period surplus and the available-funds balance therefore answer different questions.

### Planning and data-check figures

The right side shows monthly budgets, remaining startup plans, known giveaway resource values, and records needing attention.

- **Cash entries to review:** Fix these before relying on the cash totals. The count covers all dates.
- **Other log / directory checks:** Review incomplete giveaways, event records, or donor records. This count also covers all dates.
- **Giveaway rows without a usable cost:** Quantities may be counted, but their resource values are missing.
- **Recipes needing costing inputs:** Finish those recipe or ingredient details before using their estimates.

A nonzero **Known giveaway resource value** may still be only a partial total if some giveaways have costing warnings. It is never automatically deducted from funds available.

The suggested support target is a **monthly planning reference**, even if your selected reporting period is a week or a year. Set the appropriate period donation goal yourself in Setup.

## 9. Use Bake Stand Events and Donors when useful

### Bake Stand Events

Create a unique Event ID, an event date, and an event name. Location, volunteer hours, and notes are optional.

Select that Event ID in Donations, Free Product Log, and Expense Log to group the activity. A completed event record summarizes:

- Net donations assigned to the event.
- Cash expenses assigned to the event.
- Event cash balance.
- Giveaway units.
- Known resource values and uncosted giveaway rows.

Event totals cover **all valid entries linked to that ID**, not just the Dashboard reporting period. An event balance includes only explicitly linked cash expenses; it is not a fully allocated profit calculation.

### Donors

Donor records are optional. Create a unique Donor ID and display name or alias if you want to track a supporter's gifts. Contact details, consent notes, and thank-you notes are optional.

Use the Donor ID when entering a gift. The directory summarizes gift-entry counts, gross gifts, and net funds received across **all valid gifts in the workbook**.

Anonymous gifts are still included in donation and Dashboard totals without a directory record. The workbook does not generate or send thank-you messages or tax receipts.

Keep IDs consistent. Deleting or changing an ID already used in a log can break its links; avoid repurposing existing IDs for different people, events, recipes, or products.

## 10. Set up ingredient and recipe resource values

Use these tabs when you want to estimate the resources required to keep providing free products. This is separate from recording actual cash payments.

### A. Ingredients + Stock

Enter the ingredient name, stock unit, package quantity, and package planning value. Also update current stock, the low-stock threshold, source, last-updated date, and notes as needed.

For example, a 5,000 g flour package valued at 10 has a planning value of **0.002 per gram**.

The sheet calculates value per stock unit, stock planning value, and stock status. **OUT** means recorded stock is zero; **LOW** means it is at or below the alert threshold.

For donated goods, a replacement value may be useful for planning. Enter 0 only if you intentionally want that resource valued at zero. A blank package value means “not supplied,” not “free.”

**Stock quantities are manual.** Giving away a finished product does not automatically reduce flour, butter, or other ingredient stock. Update stock after baking or a stocktake.

### B. Recipe Library

Create a unique Recipe ID and enter the recipe name, category, batch yield, and recipe unit or portion.

Also enter labor hours, packaging value per recipe unit, and any other batch resource value. Enter an explicit **0** for packaging if there is none.

The Library uses the labor planning rate and waste percentage from Setup. Its packaging amount is entered **per recipe**; changing the scratch-calculator packaging default does not update Library packaging inputs.

Packaging is measured per **recipe unit**, not necessarily per box. If a batch makes 12 cookies and uses one box costing 0.60, enter **0.05 per cookie** for packaging: 0.60 ÷ 12. Do not enter the whole box cost as though every cookie uses its own box.

After its ingredient rows are complete, the recipe calculation is:

**Batch resource value = Ingredients + Labor allowance + Packaging + Waste allowance + Other batch value**

Waste is applied to ingredient and packaging values only. Fixed monthly overhead is budgeted separately.

The batch resource value is divided by batch yield to calculate the value per recipe unit. A missing or zero yield is flagged, not treated as a valid zero-cost recipe.

### C. Recipe Ingredients

Add one row per ingredient used in a recipe:

1. Choose the Recipe ID.
2. Choose the ingredient.
3. Enter the recipe quantity.
4. Choose the recipe unit.
5. Read the conversion/input check.

Several rows normally share the same Recipe ID. The Library adds their line resource values together.

Add ingredient records in Ingredients + Stock before trying to select them here. Complete the recipe in Recipe Library before using its ID.

### D. Unit Conversion

The conversion reference supports compatible weight, volume, and count units. Its volume measures use US conventions.

Examples include kg to g, lb to g, tsp to ml, and dozen to pcs. Two teaspoons convert to approximately **9.85784 ml**.

Weight and volume are not automatically interchangeable. If a recipe uses tablespoons but an ingredient is stocked in grams, the sheet shows **Weight / volume mismatch**. Weigh that ingredient and enter a compatible measured quantity, rather than assuming a universal grams-per-tablespoon value.

### E. Finish the retained examples before relying on them

In the supplied examples, the package values for **Water, Salt, and Brown Sugar** need input. The Cinnamon example also uses tablespoons against stock measured in grams.

Enter appropriate actual planning values and correct measured units, or replace these examples with your own recipes. Do not type “OK” into check cells or enter arbitrary zero values merely to remove a warning.

### F. Recipe Calculator

The Recipe Calculator provides three independent scratch areas for trying recipes. Each supports ingredient conversions, labor, packaging, waste, and batch/per-unit estimates.

Use its yellow recipe-name, yield, ingredient, quantity, unit, labor-hours, and other-value fields. Labor rate, packaging default, and waste rate come from Setup.

**These calculators do not automatically save a recipe to Recipe Library.** To use a trial recipe for Product List costing, enter it in Recipe Library and Recipe Ingredients.

Recipe and giveaway resource estimates use **current** ingredient values. Updating costs can change estimates for earlier giveaways; the workbook is not a historical batch-cost ledger. Actual cash records remain based on the amounts you entered in the money logs.

## 11. Plan overhead and startup support needs

### Overhead Expenses

Use this tab for your expected monthly operating budget: rent, utilities, insurance, transport, software, and similar items.

Enter a monthly amount. The workbook calculates annual equivalents, total monthly overhead, and planning estimates per working hour and giveaway unit. It also adds the variable-cost budget from Setup to show a suggested monthly support target.

These are **plans**, not payments. When a bill is actually paid, enter it once in Expense Log. Do not subtract the overhead plan again from the Dashboard balance.

### Startup Costs

Use Startup Costs to plan one-time needs such as a mixer, scale, equipment, or initial supplies.

Enter a unique Startup Item ID, category, item description, planned cash cost, and optional priority and notes.

When you pay for a planned item, enter the payment in Expense Log and select its Startup Item ID. The startup sheet then calculates:

- **Paid to date:** All valid linked payments, across all dates.
- **Remaining planned need:** Planned cost minus paid amount, with a minimum of 0.

If an item costs more than planned, the full payment still reduces available funds. The paid amount can exceed its plan, even though remaining planned need stops at zero.

This tab does not allocate donations to particular equipment, track restricted-fund balances, or calculate a sales-based break-even date. All products remain free.

## 12. Understand reporting periods and Analytics

Not every summary uses the same date scope.

| Summary | Date scope |
|---|---|
| Dashboard period cash figures and giveaways | Reporting start through reporting end, inclusive. |
| Product List period totals | The same reporting dates from Setup. |
| Dashboard funds available | Opening funds plus valid transactions from the beginning of your recorded history through reporting end. |
| Bake Stand Events | All valid records assigned to each Event ID. |
| Donors | All valid gifts assigned to each Donor ID. |
| Startup paid/remaining figures | All valid linked expense records, across all dates. |
| Analytics (BONUS) | January–December of the calendar year containing the reporting **start** date. |

Analytics shows monthly gross donations, fees, net donations, expenses, cash surplus/shortfall, giveaways, known resource values, and uncosted giveaway rows. The Dashboard's monthly chart uses this calendar-year summary.

Filters are useful for reviewing particular records, but **hiding rows with a filter does not change the formula-based totals**. Change the reporting dates to change period totals.

## 13. Handle donated supplies and money movements correctly

### Donated flour, equipment, or other non-cash support

Do not enter its estimated value as cash received in Donations or as a cash payment in Expense Log.

For donated ingredients, update stock and add a source note. You may use a replacement value for planning. Keep separate documentation for non-cash equipment or other gifts if needed; this edition has no dedicated in-kind valuation ledger.

### Moving existing funds from the cash jar to the bank

Moving already-recorded bakery money between locations is not a new donation or another expense. Recording it again would distort the combined funds balance.

The Dashboard shows combined recorded funds, not separate bank-account or cash-drawer balances. Reconcile those locations against your own cash counts and statements.

### Adding your own money

If you actually add new personal money to the bakery fund as a voluntary contribution, record that contribution clearly in Donations. Then record payments made from the bakery fund in Expense Log.

A bill someone pays directly without money entering or leaving the bakery fund is different from a cash donation to that fund. Keep appropriate separate notes; the workbook does not automatically manage personal reimbursements, loans, or amounts owed.

## 14. Follow a simple recording routine

### After each bake-stand day

1. Count donations and identify any amounts already recorded.
2. Record new gifts and their actual fees in Donations.
3. Record free giveaway quantities by product.
4. Record actual payments in Expense Log.
5. Link Event IDs if you use event reporting.
6. Fix Entry check warnings.
7. Review funds available and save the workbook.

### Weekly

- Reconcile recorded receipts and payments with cash counts and payment-provider or bank records.
- Update stock quantities and current package planning values.
- Review missing recipe costs and low-stock alerts.
- Keep supporting receipts and optional thank-you notes.

### Monthly

- Change the reporting start and end dates.
- Review donations, expenses, giveaways, and funding needs.
- Update budgets and the optional support goal.
- Save a dated backup copy.

Keep past transactions in the same working file unless you intentionally move to a new ledger. Do not reset Opening funds to the latest balance every month while also retaining the old transactions.

## 15. Troubleshooting

| What you see | What to check |
|---|---|
| A gift is missing from totals | Read its Entry check, confirm the received date is in the period, and make sure the amount is positive and the payment method is selected. |
| “Fee exceeds gift” | Verify the gross amount and fee from the payment record. The fee must not exceed the gift. |
| “Check donor ID,” “Check event ID,” or “Check startup ID” | Create or correct the matching record, remove duplicate IDs, or leave the optional link blank if it is not needed. |
| “Choose valid product” | Select a unique Product ID already listed in Product List. |
| Giveaway quantity is counted but its value is blank | Its Entry check may be OK while its Costing check is not. Finish the product/recipe/ingredient cost setup. |
| “Weight / volume mismatch” | Use a compatible measured unit. Do not assume that grams and milliliters convert directly. |
| “Enter positive batch yield” | Enter the number of recipe units produced by the batch. It must be greater than zero. |
| Available funds seem too high | Look for duplicated jar gifts, gross and net amounts entered as separate donations, or opening funds entered twice. |
| Available funds seem too low | Check for duplicated expenses, fees deducted twice, or missing contributions. Do not enter budgets as actual payments. |
| A ratio is blank | There may be no expenses to divide by, or no donation goal set. Check the relevant inputs rather than entering a formula manually. |
| A cell cannot be edited | Use the yellow input cell or change the relevant Setup value. Formula cells are protected intentionally. |
| Values do not update | In Excel, check **Formulas → Calculation Options → Automatic**, then recalculate. Do not overwrite calculated totals. |

If using another spreadsheet application, verify formulas, dropdowns, charts, and protection after importing the file. Compatibility should not be assumed from appearance alone.

## 16. Capacity, privacy, and important limits

### Entry capacity

| Area | Capacity |
|---|---:|
| Donations | 500 entries |
| Free Product Log | 500 entries |
| Expense Log | 500 entries |
| Recipe Ingredients | 500 ingredient lines, shared across recipes |
| Recipe Library | 50 recipes |
| Product List | 50 products |
| Ingredients + Stock | 100 ingredients |
| Bake Stand Events | 100 events |
| Donors | 100 donor records |
| Overhead Expenses | 30 budget lines |
| Startup Costs | 30 planned items |
| Recipe Calculator | 3 scratch recipes, with 12 ingredient rows each |

The main entry logs run from row 5 through row 504. Enter data inside the prepared areas.

Do not simply type below the capacity limit: formulas, named ranges, dropdowns, filters, and summaries may not include those cells. Extending the workbook requires updating all related ranges and protection, not just inserting a row.

### Privacy and protection

Sheet protection helps prevent formula changes. It is **not file encryption** and should not be treated as protection for sensitive donor information. Keep contacts optional, store backups securely, and share copies carefully.

Automatic entry IDs are worksheet identifiers, not official donation-receipt numbers. Use the payment-reference fields for bank or processor references.

### What the workbook does not do automatically

- Charge recipients, issue invoices, or create customer balances.
- Collect payments or import bank transactions.
- Reduce ingredient stock after baking or giveaways.
- Maintain separate bank-account balances, loans, or reimbursement balances.
- Allocate restricted donations or maintain an in-kind gift valuation ledger.
- Preserve historical recipe cost snapshots.
- Establish nonprofit status, determine tax deductibility, or issue tax receipts.

Confirm the tax and reporting treatment appropriate to your own situation. This workbook is an operational tracking tool, not a substitute for any required accounting, tax, or food-business compliance records.

**Everyday reminder:** Log what came in, log what actually went out, and count what you gave away. Keep the products free and the donations optional.
